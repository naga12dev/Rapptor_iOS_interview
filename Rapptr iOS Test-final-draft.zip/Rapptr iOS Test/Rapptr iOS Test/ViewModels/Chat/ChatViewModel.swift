//
//  ChatViewModel.swift
//  Rapptr iOS Test
//
//  Created by goutham on 25/06/22.
//

import Foundation
import UIKit

protocol AnyChatViewModel {
    func chatListService()
    func downloadAvatarImage(_ url: String, completionHandler: @escaping (UIImage?, NetworkError?) -> Void)
}

class ChatViewModel: AnyChatViewModel {
    var presenter: AnyChatPresenter
    private var chatClient = ChatClient()
    
    init(withPresenter presenter: AnyChatPresenter) {
        self.presenter = presenter
    }
    
    func chatListService() {
        chatClient.fetchChatData { messages in
            DispatchQueue.main.async {[weak self] in
                self?.presenter.formatResponseData(messages)
            }
        } error: { errorDescription in
            DispatchQueue.main.async {[weak self] in
                self?.presenter.formatResponseData([])
            }
        }
    }
    
    func downloadAvatarImage(_ url: String, completionHandler: @escaping (UIImage?, NetworkError?) -> Void) {
        chatClient.dowloadAvatatImage(url) { image, error in
            DispatchQueue.main.async {
                completionHandler(image, error)
            }
        }
    }
}
