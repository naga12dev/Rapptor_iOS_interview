//
//  LoginViewModel.swift
//  Rapptr iOS Test
//
//  Created by goutham on 27/06/22.
//

import Foundation


final class LoginViewModel {
    
    private var presenter: AnyLoginPresenter
    private var loginClient = LoginClient()
    
    init(withPresenter presenter: AnyLoginPresenter) {
        self.presenter = presenter
    }
    
    func loginServiceRequest(_ username: String, password: String) {
        loginClient.login(email: username, password: password) { [weak self] (message, code, interval) in
            self?.presenter.formatResponseData(message, code: code, interval: interval)
        } error: { [weak self] (error) in
            if let error = error {
                self?.presenter.formatResponseData(error, code: "", interval: nil)
            }
        }
    }
}
