//
//  ChatClient.swift
//  Rapptr iOS Test
//
//  Created by Ethan Humphrey on 8/11/21.
//

import Foundation
import UIKit

class ChatClient {
    
    var session: URLSession?
    
    init() {
        session = URLSession.shared
    }
    
    func fetchChatData(completion: @escaping ([Message]) -> Void, error errorHandler: @escaping (String?) -> Void) {
        guard let chatURL = URL(string: "http://dev.rapptrlabs.com/Tests/scripts/chat_log.php") else { return }
        let dataTask = session?.dataTask(with: chatURL, completionHandler: { data, response, error in
            if let anyError = error {
                errorHandler(anyError.localizedDescription)
            } else if let validData = data {
                do {
                    let responseModel = try JSONDecoder().decode(MessageModel.self, from: validData)
                    completion(responseModel.messages)
                } catch {
                    print("Error == \(error)")
                    errorHandler(error.localizedDescription)
                }
            }
        })
        dataTask?.resume()
    }
    
    func dowloadAvatatImage(_ url: String, completionHandler: @escaping (UIImage?, NetworkError?) -> Void) {
        
        guard let avatarURL = URL(string: url) else { return }
        
        let dataTask = session?.dataTask(with: avatarURL, completionHandler: { data, response, error in
            if let aError = error {
                print(aError)
            } else {
                if let validData = data {
                    let image = UIImage(data: validData)
                    completionHandler(image, nil)
                } else {
                    completionHandler(nil, .parse)
                }
            }
        })
        dataTask?.resume()
    }
}
