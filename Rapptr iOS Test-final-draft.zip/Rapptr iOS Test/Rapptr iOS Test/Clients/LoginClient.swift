//
//  LoginClient.swift
//  Rapptr iOS Test
//
//  Created by Ethan Humphrey on 8/11/21.
//

import Foundation


class LoginClient {
    
    var session: URLSession?
    
    init() {
        session = URLSession.shared
    }
    
    func login(email: String, password: String, completion: @escaping ((String, String, TimeInterval)) -> Void, error errorHandler: @escaping (String?) -> Void) {
        let url = String(format: "http://dev.rapptrlabs.com/Tests/scripts/login.php")
        guard let serviceUrl = URL(string: url) else { return }
        let parameterDictionary = ["email" : email, "password" : password]
        
        let jsonString = parameterDictionary.reduce("") { "\($0)\($1.0)=\($1.1)&" }.dropLast()
        guard let jsonData = jsonString.data(using: .utf8, allowLossyConversion: false) else { return }
        
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = HTTPMethod.post.rawValue
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        let serviceCallStart = Date()
        let dataTask = session?.dataTask(with: request) { (data, response, error) in
            let totalRequestDuration = NSDate().timeIntervalSince(serviceCallStart)
            if let anyError = error {
                errorHandler(anyError.localizedDescription)
            } else if let response = response as? HTTPURLResponse {
                switch response.statusCode {
                case 200..<300:
                    if let data = data {
                        do {
                            let json = try JSONDecoder().decode(LoginResponse.self, from: data)
                            let message = json.message
                            completion((message, json.code, totalRequestDuration))
                        } catch {
                            print("error")
                        }
                    }
                case 400:
                    errorHandler("The request was invalid.")
                case 401:
                    errorHandler("The username/password combination is in correct.")
                case 500:
                    errorHandler("Network failure.")
                default:
                    errorHandler("Something went wrong. Please try again.")
                }
            }
        }
        dataTask?.resume()
    }
}

struct LoginResponse: Codable {
    var code: String
    var message: String
}

enum HTTPMethod: String {
    case post   = "POST"
}

extension HTTPURLResponse {
    var isResponseOK: Bool {
      return (200...299).contains(self.statusCode)
    }
}

/**
 if let response = response as? HTTPURLResponse {
     switch response.statusCode {
     case 200:
         if let data = data {
             do {
                 let json = try JSONDecoder().decode(LoginResponse.self, from: data)
                 let message = json.message
                 completion(message)
             } catch {
                 print("error")
             }
         }
     case 500:
         print("Network failure")
     default:
         return
     }
     print(response)
 }
 */

