//
//  LoginPresenter.swift
//  Rapptr iOS Test
//
//  Created by goutham on 27/06/22.
//

import Foundation

protocol AnyLoginPresenter {
    func formatResponseData(_ message: String, code: String, interval: TimeInterval?)
    var delegate: LoginViewControllerDelgate? { get set }
}

final class LoginPresenter: AnyLoginPresenter {
    var delegate: LoginViewControllerDelgate?
    
    func formatResponseData(_ message: String, code: String, interval: TimeInterval?) {
        var serviceDuration: String = ""
        if let milliSeconds = interval?.milliseconds {
            serviceDuration = "\(milliSeconds)"
        }
        let loginDetails = LoginDetails(message: message, code: code, milliSeconds: serviceDuration)
        DispatchQueue.main.async {[weak self] in
            self?.delegate?.didUpdateUI(withData: loginDetails)
        }
    }
}
//{"code":"Success","message":"Login Successful!"}
struct LoginDetails {
    var message: String
    var code: String
    var milliSeconds: String
}


