//
//  ChatPresenter.swift
//  Rapptr iOS Test
//
//  Created by goutham on 25/06/22.
//

import Foundation
import UIKit

protocol AnyChatPresenter: AnyObject {
    func formatResponseData(_ response: [Message])
    var delegate: ChatViewControllerDelgate? { get set }
}

class ChatPresenter: AnyChatPresenter {
    weak var delegate: ChatViewControllerDelgate?
    
    func formatResponseData(_ response: [Message]) {
        delegate?.didPopulateUI(withData: response)
    }
}
