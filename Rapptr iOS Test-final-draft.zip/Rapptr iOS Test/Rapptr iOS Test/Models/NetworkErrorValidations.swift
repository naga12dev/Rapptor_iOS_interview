//
//  NetworkErrorValidations.swift
//  Rapptr iOS Test
//
//  Created by goutham on 26/06/22.
//

import Foundation

enum NetworkError: Error {
    case fetch
    case parse
    case badRequest
    case nointernetConnection
    func errorDescription() -> String {
        switch self {
        case .fetch:
            return "Failed in fetching the records."
        case .parse:
            return "Failed in fetching the records."
        case .badRequest:
            return "Bad request"
        case .nointernetConnection:
            return "No Internet Connection"
        }
    }
}

