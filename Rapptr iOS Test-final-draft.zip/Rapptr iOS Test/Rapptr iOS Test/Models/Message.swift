//
//  Message.swift
//  Rapptr iOS Test
//
//  Created by Ethan Humphrey on 8/11/21.
//

import Foundation

struct Message: Codable {
    var userID: String
    var username: String
    var avatarURL: String
    var message: String
    
    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case username = "name"
        case avatarURL = "avatar_url"
        case message
    }
    
    init(testName: String, withTestMessage message: String) {
        self.userID = ""
        self.username = testName
        self.avatarURL = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Smiley.svg/220px-Smiley.svg.png"
        self.message = message
    }
}

struct MessageModel: Codable {
    let messages: [Message]
    enum CodingKeys: String, CodingKey {
        case messages = "data"
    }
}
