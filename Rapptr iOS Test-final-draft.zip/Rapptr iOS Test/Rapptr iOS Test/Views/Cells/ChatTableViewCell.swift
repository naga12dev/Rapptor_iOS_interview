//
//  ChatTableViewCell.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit


class ChatTableViewCell: UITableViewCell {
    // MARK: - Outlets
    @IBOutlet private weak var header: UILabel!
    @IBOutlet private weak var body: UILabel!
    @IBOutlet private weak var bodyView: UIView!
    @IBOutlet private weak var avatarImageView: UIImageView!
    

    var avatarRoundCorner: CGFloat {
        avatarImageView.frame.width / 2.0
    }
    
    struct Constants {
        static let CornerRadius: CGFloat = 10
    }
    
    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        avatarImageView.layer.cornerRadius = avatarRoundCorner
        avatarImageView.layer.masksToBounds = true
        bodyView.layer.cornerRadius = Constants.CornerRadius
        bodyView.backgroundColor = .white
        
        contentView.backgroundColor = UIColor(rgb: 0xF7F7F7)
        backgroundColor = UIColor(rgb: 0xF7F7F7)
    }
    
    // MARK: - Public
    func setCellData(message: Message) {
        header.text = message.username
        body.text = message.message
    }
    
    func setAvatarImage(_ image: UIImage) {
        avatarImageView.image = image
    }
}
