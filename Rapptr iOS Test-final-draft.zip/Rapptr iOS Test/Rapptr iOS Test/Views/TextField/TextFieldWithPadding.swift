//
//  TextFieldWithPadding.swift
//  Rapptr iOS Test
//
//  Created by goutham on 28/06/22.
//

import Foundation
import UIKit

class TextFieldWithPadding: UITextField {
    var textPadding = UIEdgeInsets(
        top: 10,
        left: 24,
        bottom: 10,
        right: 20
    )

    open override func awakeFromNib() {
        //5f6063
        layer.cornerRadius = 8.0
    }
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        let rect = super.textRect(forBounds: bounds)
        return rect.inset(by: textPadding)
    }

    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        let rect = super.editingRect(forBounds: bounds)
        return rect.inset(by: textPadding)
    }
    
    func setPlaceHolderText(_ text: String) {
        attributedPlaceholder = NSAttributedString(
            string: text,
            attributes: [
                NSAttributedString.Key.foregroundColor: UIColor(rgb: 0x5F6063),
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16.0, weight: .regular)
            ]
        )
    }
}
