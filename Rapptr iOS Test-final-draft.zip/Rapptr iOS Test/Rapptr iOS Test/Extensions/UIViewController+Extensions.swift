//
//  UIViewController+Extensions.swift
//  Rapptr iOS Test
//
//  Created by goutham on 28/06/22.
//

import Foundation
import UIKit

extension UIViewController {
    open override func awakeFromNib() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    func showSpinner(onView : UIView) {
        let spinnerView = UIView.init(frame: onView.bounds)
        spinnerView.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
        spinnerView.tag = 1111
        let ai = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.large)
        ai.startAnimating()
        ai.center = spinnerView.center
        
        DispatchQueue.main.async {
            spinnerView.addSubview(ai)
            onView.addSubview(spinnerView)
        }
        
    }
    
    func removeSpinner() {
        DispatchQueue.main.async {
            if let vSpinner = self.view.viewWithTag(1111) {
                vSpinner.removeFromSuperview()
            }
        }
    }
}
