//
//  AnimationViewController.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit

class AnimationViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var animatingImage: UIImageView!
    @IBOutlet weak var imageUIView: UIView!
    @IBOutlet weak var fadeInOutButton: UIButton!
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Animation"
        self.navigationController?.navigationBar.topItem?.title = ""
        
        imageUIView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(handleCardTapped)))
        animatingImage.alpha = 1.0
    }
    
    // MARK: - Actions
    @IBAction func didPressFade(_ sender: UIButton) {
        showSpinner(onView: self.view)
        if fadeInOutButton.isSelected {
            animatingImage.fadeIn {[weak self] finished in
                if finished {
                    self?.removeSpinner()
                }
            }
        } else {
            animatingImage.fadeOut {[weak self] finished in
                if finished {
                    self?.removeSpinner()
                }
            }
        }
        fadeInOutButton.isSelected = !sender.isSelected
    }
    
    @objc private func handleCardTapped(_ gesture: UIPanGestureRecognizer) {

            if let cardView = gesture.view {
                let point = gesture.translation(in: view)
                cardView.center = CGPoint(x: cardView.center.x + point.x, y: cardView.center.y + point.y) 
                gesture.setTranslation(CGPoint.zero, in: view)
            }
        }
}







