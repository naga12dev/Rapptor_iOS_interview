//
//  ChatViewController.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit
import LoadingShimmer


protocol ChatViewControllerDelgate: AnyObject {
    func didPopulateUI(withData data: [Message])
}

class ChatViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    // MARK: - Properties
    static let cellIdentifer = "ChatTableViewCell"
    private var client: ChatClient?
    private let coverableCellsIds = [cellIdentifer,
                                     cellIdentifer,
                                     cellIdentifer,
                                     cellIdentifer,
                                     cellIdentifer
                                    ]
    
    private var messages: [Message] = [] {
        didSet {
            DispatchQueue.main.async {[weak self] in
                guard let weakSelf = self else { return }
                weakSelf.chatTable.reloadData()
            }
        }
    }

    
    private var viewModel: AnyChatViewModel?
    private(set) var presenter: AnyChatPresenter = {
        let presenter = ChatPresenter()
        return presenter
    }()
    
    // MARK: - Outlets
    @IBOutlet weak var chatTable: UITableView!
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Chat"
        self.navigationController?.navigationBar.topItem?.title = ""
        presenter.delegate = self
        viewModel = ChatViewModel(withPresenter: presenter)
        //showSpinner(onView: self.view)
        configureTable(tableView: chatTable)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {[weak self] in
            self?.viewModel?.chatListService()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        LoadingShimmer.startCovering(chatTable, with: coverableCellsIds)
    }
    
    // MARK: - Private
    private func configureTable(tableView: UITableView) {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: ChatViewController.cellIdentifer, bundle: nil), forCellReuseIdentifier: ChatViewController.cellIdentifer)
        tableView.tableFooterView = UIView(frame: .zero)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 110
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor(rgb: 0xF7F7F7)
        tableView.showsVerticalScrollIndicator = true
    }
    
    // MARK: - UITableViewDataSource
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ChatTableViewCell", for: indexPath) as? ChatTableViewCell else {
            return UITableViewCell()
        }
        
        let message = messages[indexPath.row]
        cell.setCellData(message: message)
        
        viewModel?.downloadAvatarImage(message.avatarURL, completionHandler: { image, error in
            if let _ = error {
                cell.setAvatarImage(UIImage(named: "ic_animation")!)
            } else if let anyImage = image {
                cell.setAvatarImage(anyImage)
            }
        })
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    // MARK: - UITableViewDelegate
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
        
    // MARK: - IBAction
    @IBAction func backAction(_ sender: Any) {
        let mainMenuViewController = MenuViewController()
        self.navigationController?.pushViewController(mainMenuViewController, animated: true)
    }
}

extension ChatViewController: ChatViewControllerDelgate {
    func didPopulateUI(withData data: [Message]) {
        LoadingShimmer.stopCovering(self.chatTable)
        self.messages = data
    }
}
