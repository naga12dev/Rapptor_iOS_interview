//
//  LoginViewController.swift
//  iOSTest
//
//  Copyright © 2020 Rapptr Labs. All rights reserved.

import UIKit

protocol LoginViewControllerDelgate: AnyObject {
    func didUpdateUI(withData data: LoginDetails)
}

class LoginViewController: UIViewController {
        
    // MARK: - Outlets
    @IBOutlet weak var usernameTextField: TextFieldWithPadding!
    @IBOutlet weak var passwordTextField: TextFieldWithPadding!
    
    private var viewModel: LoginViewModel?
    private var presenter: AnyLoginPresenter = {
       let presenter = LoginPresenter()
       return presenter
    }()
    
    // MARK: - Properties
    private var client: LoginClient?
   
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Login"
        self.navigationController?.navigationBar.topItem?.title = ""
        usernameTextField.setPlaceHolderText("Email")
        usernameTextField.backgroundColor = UIColor(rgb: 0xF9F9F9).withAlphaComponent(0.8)
        passwordTextField.setPlaceHolderText("Password")
        passwordTextField.backgroundColor = UIColor(rgb: 0xF9F9F9).withAlphaComponent(0.8)
        passwordTextField.isSecureTextEntry = true
        
        presenter.delegate = self
        viewModel = LoginViewModel(withPresenter: presenter)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Actions    
    @IBAction func didPressLoginButton(_ sender: Any) {
        guard let username = usernameTextField.text, !username.isEmpty,
              let password = passwordTextField.text, !password.isEmpty
        else { return }
        showSpinner(onView: self.view)
        viewModel?.loginServiceRequest(username, password: password)
    }
    
    func showAlertMessage(message: String, timeinterval: String? = nil) {
        
        var title = ""
        var msg = ""
        var okAction: UIAlertAction!
        if let timeinterval = timeinterval, !timeinterval.isEmpty {
            title = "Login Successful"
            msg = "Response time was \(timeinterval)"
            okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: showMenuViewController)
        } else {
            title = "Login"
            msg = message
            okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        }
        
        
        let alert = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func showMenuViewController(action: UIAlertAction) {
        self.navigationController?.popToRootViewController(animated: true)
    }
}

extension LoginViewController: LoginViewControllerDelgate {
    func didUpdateUI(withData data: LoginDetails) {
        removeSpinner()
        showAlertMessage(message: data.message, timeinterval: data.milliSeconds)
    }
}
